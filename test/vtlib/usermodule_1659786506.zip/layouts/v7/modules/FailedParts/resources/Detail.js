
Inventory_Detail_Js("FailedParts_Detail_Js", {}, {

    postMailSentEvent: function () {
        window.location.reload();
    },
});