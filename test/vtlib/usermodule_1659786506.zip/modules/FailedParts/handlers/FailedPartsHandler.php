<?php

class FailedPartsHandler extends VTEventHandler {

    function handleEvent($eventName, $entityData) {
        
    }

}
