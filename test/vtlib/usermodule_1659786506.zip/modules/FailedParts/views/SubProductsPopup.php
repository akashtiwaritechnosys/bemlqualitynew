<?php

class FailedParts_SubProductsPopup_View extends Inventory_SubProductsPopup_View {}