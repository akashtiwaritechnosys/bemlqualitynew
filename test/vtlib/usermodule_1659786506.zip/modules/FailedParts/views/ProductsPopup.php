<?php


class FailedParts_ProductsPopup_View extends Inventory_ProductsPopup_View {}