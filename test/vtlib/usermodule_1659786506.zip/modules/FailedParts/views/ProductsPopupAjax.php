<?php

class FailedParts_ProductsPopupAjax_View extends Inventory_ProductsPopupAjax_View {}