<?php


class FailedParts_SubProductsPopupAjax_View extends Inventory_SubProductsPopupAjax_View {}