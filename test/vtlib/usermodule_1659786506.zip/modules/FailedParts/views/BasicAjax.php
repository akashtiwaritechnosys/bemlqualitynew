<?php


class FailedParts_BasicAjax_View extends Vtiger_BasicAjax_View {
    
    
}