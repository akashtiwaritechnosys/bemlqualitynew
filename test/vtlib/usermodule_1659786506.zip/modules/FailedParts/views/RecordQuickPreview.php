<?php


class FailedParts_RecordQuickPreview_View extends Inventory_RecordQuickPreview_View {}
