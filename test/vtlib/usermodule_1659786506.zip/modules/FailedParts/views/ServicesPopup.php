<?php


class FailedParts_ServicesPopup_View extends Inventory_ServicesPopup_View {}