<?php


class FailedParts_ServicesPopupAjax_View extends Inventory_ServicesPopupAjax_View {}