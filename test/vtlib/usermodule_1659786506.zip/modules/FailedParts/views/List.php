<?php


class FailedParts_List_View extends Inventory_List_View {}
?>
