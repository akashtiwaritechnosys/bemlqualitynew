<?php

vimport('~~/modules/FailedParts/FailedPartsPDFController.php');
class FailedParts_ExportPDF_Action extends Inventory_ExportPDF_Action {}
