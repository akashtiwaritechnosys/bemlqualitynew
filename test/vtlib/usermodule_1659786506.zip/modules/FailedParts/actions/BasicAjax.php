<?php

class FailedParts_BasicAjax_Action extends Inventory_BasicAjax_Action {}
