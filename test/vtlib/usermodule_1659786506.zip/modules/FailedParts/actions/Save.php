<?php
class FailedParts_Save_Action extends Inventory_Save_Action {}
