<?php

class FailedParts_MassSave_Action extends Inventory_MassSave_Action {}