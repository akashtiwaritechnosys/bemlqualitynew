<?php

class FailedParts_MassEditRecordStructure_Model extends Inventory_MassEditRecordStructure_Model {}
