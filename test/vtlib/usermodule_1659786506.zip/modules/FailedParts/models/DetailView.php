<?php

class FailedParts_DetailView_Model extends Inventory_DetailView_Model {

}
