<?php

class FailedParts_EditRecordStructure_Model extends Inventory_EditRecordStructure_Model {}